# Portofolio Muhammad Haikal Firdaus

Dibuat dari template iPortfolio (BootstrapMade). Semua teks ada di `index.html`.

## Isi folder
- `index.html` : halaman utama (Indonesia)
- `assets/CV_Muhammad_Haikal_Firdaus.pdf` : CV yang diunduh lewat tombol "Unduh CV"
- `assets/img/` : foto, gambar sertifikat, dan gambar latar

## Deploy ke GitHub Pages
1. Buat repo bernama `mhaikalfirdaus.github.io` (public).
2. Unggah isi folder ini (bukan zip-nya) ke repo.
3. Settings, Pages, Source: Deploy from a branch, branch `main`, folder `/ (root)`.
4. Tunggu beberapa menit, lalu buka `https://mhaikalfirdaus.github.io`.

## Catatan
- Kalau CV diperbarui, ganti file di `assets/` dengan nama yang sama.
- Jangan menaruh API key atau data pribadi (misalnya nomor KTP) di repo publik.
